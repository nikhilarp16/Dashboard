from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from openpyxl import load_workbook
import manage

def index(request):
    #Read Excel

    bdf= pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')
    bdf2 = pd.read_excel(manage.base_link, sheet_name="Sheet2", keep_default_na=False, engine='openpyxl')
    #Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
        Start_Date=[]
        tb=[]
        End_Date=[]
        Alpha_Start_Date=[]
        Beta_Start_Date=[]
        Final_Start_Date=[]
        PStart_Date = []
        PEnd_Date = []
        PAlpha_Start_Date = []
        PBeta_Start_Date = []
        PFinal_Start_Date = []
        PreAlpha_Completed = []
        Alpha_Completed = []
        Beta_Completed = []
        Final_Completed = []

    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])
        tb=list(bdf['TB'])

        Start_Date = list(pd.to_datetime(bdf["PreAlpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
    #print(Start_Date)
        End_Date = list(pd.to_datetime(bdf["Final_ExpectedEnd"]).dt.strftime("%Y-%m-%d"))

        Alpha_Start_Date=list(pd.to_datetime(bdf["Alpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        Beta_Start_Date=list(pd.to_datetime(bdf["Beta_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        Final_Start_Date=list(pd.to_datetime(bdf["Final_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
    #Planned Dates
        PStart_Date = list(pd.to_datetime(bdf2["PreAlpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
    # print(Start_Date)
        PEnd_Date = list(pd.to_datetime(bdf2["Final_ExpectedEnd"]).dt.strftime("%Y-%m-%d"))

        PAlpha_Start_Date = list(pd.to_datetime(bdf2["Alpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        PBeta_Start_Date = list(pd.to_datetime(bdf2["Beta_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        PFinal_Start_Date = list(pd.to_datetime(bdf2["Final_ExpectedStart"]).dt.strftime("%Y-%m-%d"))

    #Get lists from Sheet1
        PreAlpha_Completed=list(bdf['PreAlpha'])
        Alpha_Completed = list(bdf['Alpha'])
        Beta_Completed = list(bdf['Beta'])
        Final_Completed =list(bdf['Final'])


    context={'Project':Project,'cfg':cfg,'Start_Date':Start_Date,'End_Date':End_Date,'Alpha_Start_Date':Alpha_Start_Date,
             'Beta_Start_Date':Beta_Start_Date,'Final_Start_Date':Final_Start_Date,'PreAlpha_Completed':PreAlpha_Completed,
             'Alpha_Completed':Alpha_Completed,'Beta_Completed':Beta_Completed,'Final_Completed':Final_Completed,'tb':tb,
             'PStart_Date': PStart_Date, 'PEnd_Date': PEnd_Date, 'PAlpha_Start_Date': PAlpha_Start_Date,
             'PBeta_Start_Date': PBeta_Start_Date, 'PFinal_Start_Date': PFinal_Start_Date
             }

    return render(request, 'dashboard.html', context=context)



