import datetime
from datetime import date
import os
import trialdata.views
import xlsxwriter
from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from django.templatetags.tz import datetimeobject
from openpyxl import load_workbook
import json
import manage
from pandas import ExcelWriter


def index(request):
    # Read Excel
 if(trialdata.views.trial_en):
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False,
                        engine='openpyxl')
 else:
     bdf = pd.read_excel(manage.trial_xlsx, sheet_name="Sheet1", keep_default_na=False,
                         index=False,
                         engine='openpyxl')


     # Get lists from Sheet2
 if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
 else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])

 context = {'Project': Project, 'cfg': cfg}

 return render(request, 'reader.html', context=context)



def add(request):

    data = request.POST;
    json_str = json.dumps(data)
    #print(json_str)
    resp = json.loads(json_str)
    #print(resp)


    try:
        l = int(resp['no_cfg'])
        Project = resp['Project']
        name = manage.folder + Project + ".xlsx"
        workbook = xlsxwriter.Workbook(name)
    except FileNotFoundError:
        messages.error(request, 'File Not Found')
        pass

    if (l == 0):
        Project = resp['Project']
        SOC = resp['SOC']
        Owner = resp['Owner']
        cfg = 'N/A'
        cs = resp['2']
        if (cs == 'PreAlpha'):
            pa = int(resp['3'])
            a = 0
            b = 0
            f = 0
        elif (cs == 'Alpha'):
            pa = 100
            a = int(resp['3'])
            b = 0
            f = 0
        elif (cs == 'Beta'):
            pa = 100
            a = 100
            b = int(resp['3'])
            f = 0
        elif (cs == 'Final'):
            pa = 100
            a = 100
            b = 100
            f = int(resp['3'])
        else:
            pa = 100
            a = 100
            b = 100
            f = 100
        PAStart = datetime.datetime.strptime(resp['4'], '%Y-%m-%d').strftime("%m-%d-%Y")
        AStart = datetime.datetime.strptime(resp['5'], '%Y-%m-%d').strftime("%m-%d-%Y")
        BStart = datetime.datetime.strptime(resp['6'], '%Y-%m-%d').strftime("%m-%d-%Y")
        FStart = datetime.datetime.strptime(resp['7'], '%Y-%m-%d').strftime("%m-%d-%Y")
        FEnd = datetime.datetime.strptime(resp['8'], '%Y-%m-%d').strftime("%m-%d-%Y")
        tb = int(resp['9'])
        test = int(resp['10'])
        feature = int(resp['11'])
        fca = resp['12']
        fccg = resp['13']
        ccb = resp['14']
        cce = resp['15']
        cct = resp['16']
        ccf = resp['17']
        rp = int(resp['18'])
        rip = int(resp['19'])
        rf = int(resp['20'])
        jc = int(resp['21'])
        jr = int(resp['22'])
        jo = int(resp['23'])

        df = pd.DataFrame({'Project': [Project],'Configuration':[cfg], 'SOC': [SOC],'Owner':[Owner],'PreAlpha_ExpectedStart':[PAStart],
                           'Alpha_ExpectedStart':[AStart],'Beta_ExpectedStart':[BStart],'Final_ExpectedStart':[FStart],'Final_ExpectedEnd':[FEnd],
                           'CurrentStatus':[cs],'PreAlpha':pa,'Alpha':a,'Beta':b,'Final':f,'TB':tb,'Test':test,'Feature':feature,
                           'FCAssertion':fca,'FCCoverGroup':fccg,'CCBlock':ccb,'CCExpression':cce,'CCToggle':cct,'CCFSM':ccf,'RegressionPassing':rp,
                          'RegressionInProgress':rip,'RegressionFailing':rf,'JiraClosed':jc,'JiraResolved':jr,'JiraOpen':jo
                           })
        df2=pd.DataFrame({'Project': [Project],'Configuration':[cfg],'PreAlpha_ExpectedStart':[PAStart],
                           'Alpha_ExpectedStart':[AStart],'Beta_ExpectedStart':[BStart],'Final_ExpectedStart':[FStart],'Final_ExpectedEnd':[FEnd],
                           })
        writer = pd.ExcelWriter(manage.base_link, date_format='MM-DD-YYYY',
                                datetime_format='MM-DD-YYYY', engine='openpyxl')
        # try to open an existing workbook
        writer.book = load_workbook(manage.base_link)

        # copy existing sheets
        writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
        print(writer.sheets)
        # read existing file
        reader = pd.read_excel(manage.base_link,sheet_name='Sheet1')
        df.to_excel(writer, index=False, header=False,sheet_name='Sheet1' ,startrow=len(reader) + 1)
        print(df2)
        df2.to_excel(writer, index=False, header=False,sheet_name='Sheet2' , startrow=len(reader) + 1)
        writer.close()


        worksheet = workbook.add_worksheet()
        format3 = workbook.add_format({'num_format': '%m-%d-%Y'})
        worksheet.write('A1', 'Date')
        worksheet.write('B1', 'FC_Assertion')
        worksheet.write('C1', 'FC_CoverGroup')
        worksheet.write('D1', 'CC_Block')
        worksheet.write('E1', 'CC_Expression')
        worksheet.write('F1', 'CC_Toggle')
        worksheet.write('G1', 'CC_FSM')
        worksheet.write('H1', 'R_Passing')
        worksheet.write('I1', 'R_InProgress')
        worksheet.write('J1', 'R_Failing')

        worksheet.write('A2', date.today().strftime("%m-%d-%Y"))
        worksheet.write('B2', eval('/'.join(map(str, map(float, fca.split("/")))))*100)
        worksheet.write('C2', eval('/'.join(map(str, map(float, fccg.split("/")))))*100)
        worksheet.write('D2', eval('/'.join(map(str, map(float, ccb.split("/")))))*100)
        worksheet.write('E2', eval('/'.join(map(str, map(float, cce.split("/")))))*100)
        worksheet.write('F2', eval('/'.join(map(str, map(float, cct.split("/")))))*100)
        if(ccf=='0/0'):
            worksheet.write('G2',0)
        else:
            worksheet.write('G2', eval('/'.join(map(str, map(float, ccf.split("/")))))*100)
        worksheet.write('H2', rp)
        worksheet.write('I2', rip)
        worksheet.write('J2', rf)

    else:
        cfg = [None] * l
        PAStart = [None] * l
        for i in range(l):
            Project = resp['Project']
            SOC = resp['SOC']
            Owner = resp['Owner']
            cfg = resp[str(1+i*23)]

            cs = resp[str(2+i*23)]
            if (cs == 'PreAlpha'):
                pa = int(resp[str(3+i*23)])
                a = 0
                b = 0
                f = 0
            elif (cs == 'Alpha'):
                pa = 100
                a = int(resp[str(3+i*23)])
                b = 0
                f = 0
            elif (cs == 'Beta'):
                pa = 100
                a = 100
                b = int(resp[str(3+i*23)])
                f = 0
            elif (cs == 'Final'):
                pa = 100
                a = 100
                b = 100
                f = int(resp['3'])
            else:
                pa = 100
                a = 100
                b = 100
                f = 100
            PAStart = datetime.datetime.strptime(resp[str(4+i*23)], '%Y-%m-%d').strftime("%m-%d-%Y")
            AStart = datetime.datetime.strptime(resp[str(5+i*23)], '%Y-%m-%d').strftime("%m-%d-%Y")
            BStart = datetime.datetime.strptime(resp[str(6+i*23)], '%Y-%m-%d').strftime("%m-%d-%Y")
            FStart = datetime.datetime.strptime(resp[str(7+i*23)], '%Y-%m-%d').strftime("%m-%d-%Y")
            FEnd = datetime.datetime.strptime(resp[str(8+i*23)], '%Y-%m-%d').strftime("%m-%d-%Y")
            tb = int(resp[str(9+i*23)])
            test = int(resp[str(10+i*23)])
            feature = int(resp[str(11+i*23)])
            fca = resp[str(12+i*23)]
            fccg = resp[str(13+i*23)]
            ccb = resp[str(14+i*23)]
            cce = resp[str(15+i*23)]
            cct = resp[str(16+i*23)]
            ccf = resp[str(17+i*23)]
            rp = int(resp[str(18+i*23)])
            rip = int(resp[str(19+i*23)])
            rf = int(resp[str(20+i*23)])
            jc = int(resp[str(21+i*23)])
            jr = int(resp[str(22+i*23)])
            jo = int(resp[str(23+i*23)])
            df = pd.DataFrame({'Project': [Project], 'Configuration': [cfg], 'SOC': [SOC], 'Owner': [Owner],
                               'PreAlpha_ExpectedStart': [PAStart],
                               'Alpha_ExpectedStart': [AStart], 'Beta_ExpectedStart': [BStart],
                               'Final_ExpectedStart': [FStart], 'Final_ExpectedEnd': [FEnd],
                               'CurrentStatus': [cs], 'PreAlpha': pa, 'Alpha': a, 'Beta': b, 'Final': f, 'TB': tb,
                               'Test': test, 'Feature': feature,
                               'FCAssertion': fca, 'FCCoverGroup': fccg, 'CCBlock': ccb, 'CCExpression': cce,
                               'CCToggle': cct, 'CCFSM': ccf, 'RegressionPassing': rp,
                               'RegressionInProgress': rip, 'RegressionFailing': rf, 'JiraClosed': jc,
                               'JiraResolved': jr, 'JiraOpen': jo
                               })
            df2 = pd.DataFrame({'Project': [Project], 'Configuration': [cfg], 'PreAlpha_ExpectedStart': [PAStart],
                               'Alpha_ExpectedStart': [AStart], 'Beta_ExpectedStart': [BStart],
                               'Final_ExpectedStart': [FStart], 'Final_ExpectedEnd': [FEnd],
                               })
            writer = pd.ExcelWriter(manage.base_link, date_format='MM-DD-YYYY',
                                    datetime_format='MM-DD-YYYY', engine='openpyxl')
            # try to open an existing workbook
            writer.book = load_workbook(manage.base_link)
            # copy existing sheets
            writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
            # read existing file
            reader = pd.read_excel(manage.base_link,sheet_name='Sheet1')
            df.to_excel(writer, index=False, header=False, sheet_name='Sheet1',startrow=len(reader) + 1)
            df2.to_excel(writer, index=False, header=False, sheet_name='Sheet2', startrow=len(reader) + 1)
            writer.close()
            worksheet = workbook.add_worksheet(cfg)
            format3 = workbook.add_format({'num_format': '%m-%d-%Y'})
            worksheet.write('A1', 'Date')
            worksheet.write('B1', 'FC_Assertion')
            worksheet.write('C1', 'FC_CoverGroup')
            worksheet.write('D1', 'CC_Block')
            worksheet.write('E1', 'CC_Expression')
            worksheet.write('F1', 'CC_Toggle')
            worksheet.write('G1', 'CC_FSM')
            worksheet.write('H1', 'R_Passing')
            worksheet.write('I1', 'R_InProgress')
            worksheet.write('J1', 'R_Failing')

            worksheet.write('A2', date.today().strftime("%m-%d-%Y"))
            worksheet.write('B2', eval('/'.join(map(str, map(float, fca.split("/")))))*100)
            worksheet.write('C2', eval('/'.join(map(str, map(float, fccg.split("/")))))*100)
            worksheet.write('D2', eval('/'.join(map(str, map(float, ccb.split("/")))))*100)
            worksheet.write('E2', eval('/'.join(map(str, map(float, cce.split("/")))))*100)
            worksheet.write('F2', eval('/'.join(map(str, map(float, cct.split("/")))))*100)
            if (ccf == '0/0'):
                worksheet.write('G2', 0)
            else:
                worksheet.write('G2', eval('/'.join(map(str, map(float, ccf.split("/"))))) * 100)
            worksheet.write('H2', rp)
            worksheet.write('I2', rip)
            worksheet.write('J2', rf)


    workbook.close()

    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False,
                        engine='openpyxl')

    # Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])

    context = {'Project': Project, 'cfg': cfg}



    messages.success(request, 'Project Added successfully')
    return render(request, 'reader.html', context=context)
