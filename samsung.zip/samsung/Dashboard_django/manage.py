#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import socket
import sys

from datetime import date, datetime

#Change the below variables
loc='D:/samsung/'
host_loc='D:/samsung/Dashboard_django/'
folder='D:/samsung/excels/'
data='D:/samsung/excels/Weekly_Report.xlsx'
trial_xlsx='D:/samsung/excels//Weekly_Report_trial.xlsx'
weekday = 2 # 0-Monday 1-Tuesday 2-Wednesday 3-Thursday 4-Friday 5- Saturday
ip_address=socket.gethostbyname(socket.gethostname())
base_link=data

def main():
    import project_update
    project_update.update_xlsx()

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()



