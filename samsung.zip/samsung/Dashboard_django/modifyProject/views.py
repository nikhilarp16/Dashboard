import datetime
import json
import os
from datetime import date
import openpyxl
from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from openpyxl import load_workbook
from pandas import ExcelWriter
from xlrd import open_workbook
from xlutils.copy import copy
import manage

def index(request):

    #Read Excel
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')

    #Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
        h_list=[]
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])
        h_list = list(bdf.columns.values)


    context={'Project_v':Project_v,'Project':Project,'cfg':cfg,'h_list':h_list}

    return render(request, 'graph.html', context=context)

def project(request):
    name = request.POST.get('submit', '')

    #print(name)
    return render(request, 'trial.html')
def modified(request):

    data = request.POST
    json_str = json.dumps(data)
    resp = json.loads(json_str)
    #print(resp)
    proj_name=resp['Name']
    cfg_name=resp['ip']
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
    bdf2=pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
    h_list = list(bdf.columns.values)
    global df,dataframe
    try:

     q = bdf['Project'] == resp['Name']
     wq = bdf['Configuration'] == resp['ip']
     q2 = bdf2['Project'] == resp['Name']
     wq2 = bdf2['Configuration'] == resp['ip']
     z=[]
     z2=[]
     y=0
     for x in q:
            if x == wq[y] == True:
                z.append(y)
            y = y + 1
        #print(z)
     y=0
     for x in q2:
            if x == wq2[y] == True:
                z2.append(y)
            y = y + 1
     wbk = openpyxl.load_workbook(manage.base_link)
     wks = wbk.worksheets[0];
     wks2 = wbk.worksheets[1];
     for key in resp.keys():
      if ('sel' in key):
       for x in range(len(h_list)):
        if(h_list[x]==resp[key]):
            v=key.split('_')[1]
            #print(v)
            col=x;
            #print(col)
            if ((x > 3) and (x < 9)):
                val=datetime.datetime.strptime(resp[v], '%Y-%m-%d').strftime("%m-%d-%Y")
            elif (((x > 9) and (x < 17)) or (x > 22)):
                val = int(resp[v])
            else:
                val=resp[v]
            wks.cell(row=(z[0] + 2), column=col+1, value=val)
            if((resp[key]=='Project') or (resp[key]=='Configuration')):
                wks2.cell(row=(z2[0] + 2), column=col + 1, value=val)

     wbk.save(manage.base_link)
     wbk.close()
     bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
     for key in resp.keys():

         if((resp[key] == 'Project')):
             v = key.split('_')[1]
             os.rename(manage.folder+proj_name+'.xlsx',manage.folder+resp[v]+'.xlsx')
             proj_name=resp[v]
         if(resp[key] == 'Configuration'):
             v = key.split('_')[1]
             ss = openpyxl.load_workbook(manage.folder+proj_name+'.xlsx')
             if(resp['ip']!='N/A'):
                ss_sheet = ss[resp['ip']]
             else:
                 ss_sheet =ss['Sheet1']
             print(ss_sheet)
             if(resp[v]=='N/A'):
                 ss_sheet.title ="Sheet1"
             else:
              cfg_name=resp[v]
              ss_sheet.title=resp[v]

             print(ss_sheet)
             ss.save(manage.folder+proj_name+'.xlsx')
         if ((resp[key] == 'FCAssertion') or (resp[key] == 'FCCoverGroup') or (resp[key] == 'CCBlock') or (
                 resp[key] == 'CCExpression') or (resp[key] == 'CCToggle')
                 or (resp[key] == 'CCFSM') or (resp[key] == 'RegressionPassing') or (
                         resp[key] == 'RegressionInProgress') or (resp[key] == 'RegressionFailing')):

             if(cfg_name=='N/A'):
                sheetname="Sheet1"
             else:
                sheetname=cfg_name
             proj_df = pd.read_excel(manage.folder+proj_name+'.xlsx', sheet_name=sheetname, keep_default_na=False,
                                   index=False, engine='openpyxl')
             if(proj_df.iloc[len(proj_df)-1, 0]==date.today().strftime("%m-%d-%Y")):

                    proj_df = proj_df.drop(len(proj_df)-1)

             if ((bdf._get_value(z[0], 'CCFSM')) == '0/0'):
                    df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                    eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                   'FC_CoverGroup': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                   'CC_Block': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                   'CC_Expression': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                   'CC_Toggle': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                   'CC_FSM': 0,
                                   'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                   'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                   'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                   })

             else:
                    df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                    eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                   'FC_CoverGroup': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                   'CC_Block': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                   'CC_Expression': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                   'CC_Toggle': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                   'CC_FSM': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,
                                   'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                   'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                   'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                   })

             s=proj_df.append(df,ignore_index=True)
             book = load_workbook(manage.folder+proj_name+'.xlsx')
             writer = pd.ExcelWriter(manage.folder+proj_name+'.xlsx',
                              date_format='MM-DD-YYYY', datetime_format='MM-DD-YYYY', engine='openpyxl')
             writer.book = book
             writer.sheets = dict((ws.title, ws) for ws in book.worksheets)
             s.to_excel(writer, sheet_name=sheetname, index=False)
             writer.save()
             writer.close()
    except FileNotFoundError:
        messages.error(request, 'Cannot get file')
    pass
    messages.success(request, 'Modification successful')
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])


    context = { 'Project': Project, 'cfg': cfg}

    return render(request, 'graph.html', context=context)


