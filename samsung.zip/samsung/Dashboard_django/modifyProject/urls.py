from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
path('../trial', views.project, name='project'),
path('modified', views.modified, name='modified'),
]