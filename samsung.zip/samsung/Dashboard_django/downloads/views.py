import os
from datetime import date
from wsgiref.util import FileWrapper
from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from openpyxl import load_workbook
import docx
from docx import Document
from django.conf import settings
from django.http import HttpResponse, Http404
from pandas import unique
import manage

def index(request):

    #Read Excel
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')

    #Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])

    context={'Project':Project,'Projectv':Project_v,'cfg':cfg}

    return render(request, 'downloads.html', context=context)
def doc(request):

 if request.POST:
  if 'but1' in request.POST:
       filename = manage.base_link
       with open(filename, 'rb') as fh:
           response = HttpResponse(fh.read(), content_type='application/vnd.ms-excel')
           response['Content-Length'] = os.path.getsize(filename)
           response['Content-Disposition'] = 'attachment;  filename=%s' % 'Weekly_Report_'+date.today().strftime("%m-%d-%Y")+'.xlsx'

       return response
  elif 'but2' in request.POST:

   pr = request.POST.get('Name', '')
   bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
   projx=[]
   if(pr=='All'):
        projx=list(bdf['Project'].unique())
        link = manage.folder + 'All.docx'
        z = 'All_docReport'+date.today().strftime("%m-%d-%Y")+'.docx'
   else:
        projx=[pr]
        link = manage.folder + pr + '.docx'
        z = pr + '_docReport.docx'
   document = Document()
   for proj in projx:

    print(proj)
    q = bdf['Project'] == proj
    y = 0
    n = []
    c = []
    for x in q:
        if x == True:
            n.append(y)
            c.append(bdf._get_value(y, 'Configuration'))

        y = y + 1



    #Hyperlink h = document.AddHyperlink("Google", new Url("http://www.google.com"));
    document.add_heading('Project ' + proj + ' Report', 0)
    paragraph = document.add_paragraph('Report generated on ' + date.today().strftime("%m/%d/%Y"))
    paragraph.alignment = 2
    p = document.add_paragraph(' ')
    p.add_run('Project Name: ').bold = True
    p.add_run(proj)

    p = document.add_paragraph()
    p.add_run('Owner: ').bold = True
    p.add_run(bdf._get_value(n[0], 'Owner'))
    p = document.add_paragraph()
    p.add_run('SOC: ').bold = True
    p.add_run(bdf._get_value(n[0], 'SOC'))
    p = document.add_paragraph(' ')
    p.add_run(' Configurations: ').bold = True
    p.add_run(i + ',' for i in c)
    p = document.add_paragraph()
    p.add_run('TB Completed: ').bold = True
    x = 0
    for i in range(len(n)):
        x = x + float(bdf._get_value(n[i], 'TB'))
    x = x / len(n)
    p.add_run(str(x) + '%')

    p = document.add_paragraph()
    p.add_run('Test Completed: ').bold = True
    x = 0
    for i in range(len(n)):
        x = x + float(bdf._get_value(n[i], 'Test'))
    x = x / len(n)
    p.add_run(str(x) + '%')

    p = document.add_paragraph()
    p.add_run('Feature: ').bold = True
    x = 0
    for i in range(len(n)):
        x = x + float(bdf._get_value(n[i], 'Feature'))
    x = x / len(n)
    p.add_run(str(x) + '%')
    if (len(c) > 1):
        document.add_heading('Functional Coverage', level=2)
        table = document.add_table(rows=3, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
        hdr_cells[1].paragraphs[0].add_run('Average Percentage').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Assertion'
        x = 0;
        for i in range(len(n)):
            x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'FCAssertion')).split("/")))))
        x = (x / len(n)) * 100
        hdr_cells[1].text = str(x)
        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Cover Group'
        x = 0;
        for i in range(len(n)):
            x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'FCCoverGroup')).split("/")))))
        x = (x / len(n)) * 100
        hdr_cells[1].text = str(x)

        document.add_heading('Code Coverage', level=2)
        table = document.add_table(rows=4, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
        hdr_cells[1].paragraphs[0].add_run('Average Percentage').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Block'
        x = 0;
        for i in range(len(n)):
            x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCBlock')).split("/")))))
        x = (x / len(n)) * 100
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Expression'
        x = 0;
        for i in range(len(n)):
            x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCExpression')).split("/")))))
        x = (x / len(n)) * 100
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Toggle'
        x = 0;
        for i in range(len(n)):
            x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCToggle')).split("/")))))
        x = (x / len(n)) * 100
        hdr_cells[1].text = str(x)

        if (bdf._get_value(n[i], 'CCFSM') != '0/0'):
            row_cells = table.add_row().cells
            row_cells[0].text = 'FSM'
            x = 0;
            for i in range(len(n)):
                x = x + eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCFSM')).split("/")))))
            x = (x / len(n)) * 100
            row_cells[1].text = str(x)

        document.add_heading('Regression', level=2)
        table = document.add_table(rows=4, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('').bold = True
        hdr_cells[1].paragraphs[0].add_run('Percentage').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Passing'
        Total = 0
        x = 0;
        for i in range(len(n)):
            x = x + int(bdf._get_value(n[i], 'RegressionPassing'))
            Total = Total + int(bdf._get_value(n[i], 'RegressionPassing')) + int(
                bdf._get_value(n[i], 'RegressionInProgress')) + int(bdf._get_value(n[i], 'RegressionFailing'))
        x = (x / Total) * 100
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'InProgress'
        x = 0;
        for i in range(len(n)):
            x = x + int(bdf._get_value(n[i], 'RegressionInProgress'))
        x = (x / Total) * 100
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Failing'
        x = 0;
        for i in range(len(n)):
            x = x + int(bdf._get_value(n[i], 'RegressionFailing'))
        x = (x / Total) * 100
        hdr_cells[1].text = str(x)

        document.add_heading('Jira', level=2)
        table = document.add_table(rows=4, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('').bold = True
        hdr_cells[1].paragraphs[0].add_run('Number of Issues').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Closed'
        x = 0
        for i in range(len(n)):
            x = x + bdf._get_value(n[i], 'JiraClosed')
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Resolved'
        x = 0
        for i in range(len(n)):
            x = x + bdf._get_value(n[i], 'JiraResolved')
        hdr_cells[1].text = str(x)

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Open'
        x = 0
        for i in range(len(n)):
            x = x + bdf._get_value(n[i], 'JiraOpen')
        hdr_cells[1].text = str(x)
    else:
        p = document.add_paragraph()
        p.add_run('Current Status: ').bold = True
        cs = bdf._get_value(n[i], 'CurrentStatus')
        if (cs == 'PreAlpha'):
            comp = float(bdf._get_value(n[i], 'PreAlpha'))
        elif (cs == 'Alpha'):
            comp = float(bdf._get_value(n[i], 'Alpha'))
        elif (cs == 'Beta'):
            comp = float(bdf._get_value(n[i], 'Beta'))
        else:
            comp = float(bdf._get_value(n[i], 'Final'))
        p.add_run(bdf._get_value(n[i], 'CurrentStatus') + '(' + str(comp) + '% Completed)')

        document.add_heading('Functional Coverage', level=2)
        table = document.add_table(rows=3, cols=3)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
        hdr_cells[1].paragraphs[0].add_run('Completed').bold = True
        hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True
        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Assertion'
        hdr_cells[1].text = bdf._get_value(n[0], 'FCAssertion')
        hdr_cells[2].text = str(
            eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'FCAssertion')).split("/"))))) * 100)
        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Cover Group'
        hdr_cells[1].text = bdf._get_value(n[0], 'FCCoverGroup')
        hdr_cells[2].text = str(
            eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'FCCoverGroup')).split("/"))))) * 100)

        document.add_heading('Code Coverage', level=2)
        table = document.add_table(rows=4, cols=3)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
        hdr_cells[1].paragraphs[0].add_run('Completed').bold = True
        hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Block'
        hdr_cells[1].text = bdf._get_value(n[0], 'CCBlock')
        hdr_cells[2].text = str(
            eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'CCBlock')).split("/"))))) * 100)

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Expression'
        hdr_cells[1].text = bdf._get_value(n[0], 'CCExpression')
        hdr_cells[2].text = str(
            eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'CCExpression')).split("/"))))) * 100)

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Toggle'
        hdr_cells[1].text = bdf._get_value(n[0], 'CCToggle')
        hdr_cells[2].text = str(
            eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'CCToggle')).split("/"))))) * 100)

        if (bdf._get_value(n[i], 'CCFSM') != '0/0'):
            row_cells = table.add_row().cells
            row_cells[0].text = 'FSM'
            row_cells[1].text = bdf._get_value(n[0], 'CCFSM')
            row_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[0], 'CCFSM')).split("/"))))) * 100)

        document.add_heading('Regression', level=2)
        table = document.add_table(rows=4, cols=3)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('').bold = True
        hdr_cells[1].paragraphs[0].add_run('Number of Regressions').bold = True
        hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True

        Total = int(bdf._get_value(n[0], 'RegressionPassing')) + int(
            bdf._get_value(n[0], 'RegressionInProgress')) + int(bdf._get_value(n[0], 'RegressionFailing'))
        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Passing'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'RegressionPassing'))
        hdr_cells[2].text = str((float(bdf._get_value(n[0], 'RegressionPassing')) / Total) * 100)

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'InProgress'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'RegressionInProgress'))
        hdr_cells[2].text = str((float(bdf._get_value(n[0], 'RegressionInProgress')) / Total) * 100)

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Failing'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'RegressionFailing'))
        hdr_cells[2].text = str((float(bdf._get_value(n[0], 'RegressionFailing')) / Total) * 100)

        document.add_heading('Jira', level=2)
        table = document.add_table(rows=4, cols=2)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('').bold = True
        hdr_cells[1].paragraphs[0].add_run('Number of Regressions').bold = True

        hdr_cells = table.rows[1].cells
        hdr_cells[0].text = 'Closed'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'JiraClosed'))

        hdr_cells = table.rows[2].cells
        hdr_cells[0].text = 'Resolved'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'JiraResolved'))

        hdr_cells = table.rows[3].cells
        hdr_cells[0].text = 'Open'
        hdr_cells[1].text = str(bdf._get_value(n[0], 'JiraOpen'))
    if (c[0] != 'N/A'):
        for i in range(len(n)):
            document.add_page_break()
            document.add_heading(proj+' - Configuration: ' + c[i], 0)
            p = document.add_paragraph()
            p.add_run('Current Status: ').bold = True
            cs = bdf._get_value(n[i], 'CurrentStatus')
            if (cs == 'PreAlpha'):
                comp = float(bdf._get_value(n[i], 'PreAlpha'))
            elif (cs == 'Alpha'):
                comp = float(bdf._get_value(n[i], 'Alpha'))
            elif (cs == 'Beta'):
                comp = float(bdf._get_value(n[i], 'Beta'))
            else:
                comp = float(bdf._get_value(n[i], 'Final'))
            p.add_run(bdf._get_value(n[i], 'CurrentStatus') + '(' + str(comp) + '% Completed)')

            p = document.add_paragraph()
            p.add_run('TB Completed: ').bold = True
            p.add_run(str(bdf._get_value(n[i], 'TB')) + '%')

            p = document.add_paragraph()
            p.add_run('Test Completed: ').bold = True
            p.add_run(str(bdf._get_value(n[i], 'Test')) + '%')

            p = document.add_paragraph()
            p.add_run('Feature: ').bold = True
            p.add_run(str(bdf._get_value(n[i], 'Feature')) + '%')

            document.add_heading('Functional Coverage', level=2)
            table = document.add_table(rows=3, cols=3)
            hdr_cells = table.rows[0].cells
            hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
            hdr_cells[1].paragraphs[0].add_run('Completed').bold = True
            hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True
            hdr_cells = table.rows[1].cells
            hdr_cells[0].text = 'Assertion'
            hdr_cells[1].text = bdf._get_value(n[i], 'FCAssertion')
            hdr_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'FCAssertion')).split("/"))))) * 100)
            hdr_cells = table.rows[2].cells
            hdr_cells[0].text = 'Cover Group'
            hdr_cells[1].text = bdf._get_value(n[i], 'FCCoverGroup')
            hdr_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'FCCoverGroup')).split("/"))))) * 100)

            document.add_heading('Code Coverage', level=2)
            table = document.add_table(rows=4, cols=3)
            hdr_cells = table.rows[0].cells
            hdr_cells[0].paragraphs[0].add_run('Coverage').bold = True
            hdr_cells[1].paragraphs[0].add_run('Completed').bold = True
            hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True

            hdr_cells = table.rows[1].cells
            hdr_cells[0].text = 'Block'
            hdr_cells[1].text = bdf._get_value(n[i], 'CCBlock')
            hdr_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCBlock')).split("/"))))) * 100)

            hdr_cells = table.rows[2].cells
            hdr_cells[0].text = 'Expression'
            hdr_cells[1].text = bdf._get_value(n[i], 'CCExpression')
            hdr_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCExpression')).split("/"))))) * 100)

            hdr_cells = table.rows[3].cells
            hdr_cells[0].text = 'Toggle'
            hdr_cells[1].text = bdf._get_value(n[i], 'CCToggle')
            hdr_cells[2].text = str(
                eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCToggle')).split("/"))))) * 100)

            if (bdf._get_value(n[i], 'CCFSM') != '0/0'):
                row_cells = table.add_row().cells
                row_cells[0].text = 'FSM'
                row_cells[1].text = bdf._get_value(n[i], 'CCFSM')
                row_cells[2].text = str(
                    eval('/'.join(map(str, map(float, (bdf._get_value(n[i], 'CCFSM')).split("/"))))) * 100)

            document.add_heading('Regression', level=2)
            table = document.add_table(rows=4, cols=3)
            hdr_cells = table.rows[0].cells
            hdr_cells[0].paragraphs[0].add_run('').bold = True
            hdr_cells[1].paragraphs[0].add_run('Number of Regressions').bold = True
            hdr_cells[2].paragraphs[0].add_run('Percentage').bold = True

            Total = int(bdf._get_value(n[i], 'RegressionPassing')) + int(
                bdf._get_value(n[i], 'RegressionInProgress')) + int(bdf._get_value(n[i], 'RegressionFailing'))
            hdr_cells = table.rows[1].cells
            hdr_cells[0].text = 'Passing'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'RegressionPassing'))
            hdr_cells[2].text = str((float(bdf._get_value(n[i], 'RegressionPassing')) / Total) * 100)

            hdr_cells = table.rows[2].cells
            hdr_cells[0].text = 'InProgress'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'RegressionInProgress'))
            hdr_cells[2].text = str((float(bdf._get_value(n[i], 'RegressionInProgress')) / Total) * 100)

            hdr_cells = table.rows[3].cells
            hdr_cells[0].text = 'Failing'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'RegressionFailing'))
            hdr_cells[2].text = str((float(bdf._get_value(n[i], 'RegressionFailing')) / Total) * 100)

            document.add_heading('Jira', level=2)
            table = document.add_table(rows=4, cols=2)
            hdr_cells = table.rows[0].cells
            hdr_cells[0].paragraphs[0].add_run('').bold = True
            hdr_cells[1].paragraphs[0].add_run('Number of Regressions').bold = True

            hdr_cells = table.rows[1].cells
            hdr_cells[0].text = 'Closed'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'JiraClosed'))

            hdr_cells = table.rows[2].cells
            hdr_cells[0].text = 'Resolved'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'JiraResolved'))

            hdr_cells = table.rows[3].cells
            hdr_cells[0].text = 'Open'
            hdr_cells[1].text = str(bdf._get_value(n[i], 'JiraOpen'))
    elif(pr=='All'):
        document.add_page_break()

   document.save(link)


   filename=link
   with open(filename, 'rb') as fh:
        response = HttpResponse(fh.read(),content_type='application/vnd.ms-word')
        response['Content-Length'] = os.path.getsize(filename)
        response['Content-Disposition'] = 'attachment;  filename=%s' % z

   return response
  elif 'but3' in request.POST:
       bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                           engine='openpyxl')
       link=manage.folder+"Weekly_Report_"+date.today().strftime("%m-%d-%Y")+".xlsx"
       writer = pd.ExcelWriter(link, engine='xlsxwriter')
       bdf.to_excel(writer, index=False)
       writer.save()
       if (len(bdf) == 0):
           Project = []
           Project_v = []
           cfg = []
       else:
           Project = list(bdf['Project'])
           Project_v = list(bdf['Project'].unique())

           cfg = list(bdf['Configuration'])

       context = {'Project': Project, 'Projectv': Project_v, 'cfg': cfg}

       return render(request, 'downloads.html', context=context)



