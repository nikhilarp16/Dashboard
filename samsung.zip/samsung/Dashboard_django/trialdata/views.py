import os
import shutil

from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from openpyxl import load_workbook
import manage
import socket
trial_en=False
def index(request):
    #Read Excel

 if (manage.ip_address == socket.gethostbyname(socket.gethostname())):

    bdf= pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])

    context = {'Project': Project, 'cfg': cfg}

    return render(request, 'trialdata.html', context=context)
def trial(request):
    trial_en=False
    if 'but1' in request.POST:
        trial_en=True
        manage.base_link = manage.trial_xlsx
    if 'but2' in request.POST:
        manage.base_link = manage.data
        print(manage.base_link)
    if 'but3' in request.POST:
        folder1 = request.POST.get('folder', '')
        dest = request.POST.get('dest', '')
        z=0
        if (folder1 == 'Reports Directory'):
            source = manage.folder
            dest1 = dest+'/'
            if not os.path.exists(dest):
                print('no dir')
                os.makedirs(dest)
            files = os.listdir(source)
            for f in files:
                shutil.move(source + f, dest1)
            b=manage.data.split('/')
            if(manage.folder+b[len(b)-1]==manage.base_link):
                manage.base_link = dest1 + b[len(b)-1]
                z=1
                print(z)
            manage.folder=dest1

            f = open(manage.host_loc+'manage.py', 'r')
            linelist = f.readlines()
            f.close
            print(linelist)
            # Re-open file here
            f2 = open(manage.host_loc+'manage.py', 'w')
            y = "folder=\'%s\'\n" % (manage.folder)

            for line in linelist:
                if 'folder' in line:
                    line = "folder=\'%s\'\n" % (dest1)
                    print(line)
                if 'trial_xlsx' in line:
                    line = "trial_xlsx=\'%sWeekly_Report_trial.xlsx\'\n" % (dest1)
                if(z==1):
                    if 'data=' in line:
                        line = "data=\'%sWeekly_Report.xlsx\'\n" % (dest1)
                f2.write(line)

            f2.close()
        if (folder1 == 'Base Report(xlsx)'):
            x=manage.base_link.split('/')
            source = manage.base_link.split(x[len(x)-1])[0]
            dest1 = dest+'/'
            if not os.path.exists(dest):
                print('no dir')
                os.makedirs(dest)
            files = os.listdir(source)
            for f in files:
                if(f==x[len(x)-1]):
                    shutil.move(source + f, dest1)
                    break

            manage.base_link=dest1+f

            f = open(manage.host_loc + 'manage.py', 'r')
            linelist = f.readlines()
            f.close
            print(linelist)
            # Re-open file here
            f2 = open(manage.host_loc + 'manage.py', 'w')

            for line in linelist:
                if 'data=\'' in line:
                    line = "data=\'%s\'\n" % (dest1+x[len(x)-1])
                f2.write(line)
            f2.close()
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False, engine='openpyxl')
    bdf2 = pd.read_excel(manage.base_link, sheet_name="Sheet2", keep_default_na=False, engine='openpyxl')
    # Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v = []
        cfg = []
        Start_Date = []
        tb = []
        End_Date = []
        Alpha_Start_Date = []
        Beta_Start_Date = []
        Final_Start_Date = []
        PStart_Date = []
        PEnd_Date = []
        PAlpha_Start_Date = []
        PBeta_Start_Date = []
        PFinal_Start_Date = []
        PreAlpha_Completed = []
        Alpha_Completed = []
        Beta_Completed = []
        Final_Completed = []

    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])
        tb = list(bdf['TB'])

        Start_Date = list(pd.to_datetime(bdf["PreAlpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        # print(Start_Date)
        End_Date = list(pd.to_datetime(bdf["Final_ExpectedEnd"]).dt.strftime("%Y-%m-%d"))

        Alpha_Start_Date = list(pd.to_datetime(bdf["Alpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        Beta_Start_Date = list(pd.to_datetime(bdf["Beta_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        Final_Start_Date = list(pd.to_datetime(bdf["Final_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        # Planned Dates
        PStart_Date = list(pd.to_datetime(bdf2["PreAlpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        # print(Start_Date)
        PEnd_Date = list(pd.to_datetime(bdf2["Final_ExpectedEnd"]).dt.strftime("%Y-%m-%d"))

        PAlpha_Start_Date = list(pd.to_datetime(bdf2["Alpha_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        PBeta_Start_Date = list(pd.to_datetime(bdf2["Beta_ExpectedStart"]).dt.strftime("%Y-%m-%d"))
        PFinal_Start_Date = list(pd.to_datetime(bdf2["Final_ExpectedStart"]).dt.strftime("%Y-%m-%d"))

        # Get lists from Sheet1
        PreAlpha_Completed = list(bdf['PreAlpha'])
        Alpha_Completed = list(bdf['Alpha'])
        Beta_Completed = list(bdf['Beta'])
        Final_Completed = list(bdf['Final'])

    context = {'Project': Project, 'cfg': cfg, 'Start_Date': Start_Date, 'End_Date': End_Date,
               'Alpha_Start_Date': Alpha_Start_Date,
               'Beta_Start_Date': Beta_Start_Date, 'Final_Start_Date': Final_Start_Date,
               'PreAlpha_Completed': PreAlpha_Completed,
               'Alpha_Completed': Alpha_Completed, 'Beta_Completed': Beta_Completed, 'Final_Completed': Final_Completed,
               'tb': tb,
               'PStart_Date': PStart_Date, 'PEnd_Date': PEnd_Date, 'PAlpha_Start_Date': PAlpha_Start_Date,
               'PBeta_Start_Date': PBeta_Start_Date, 'PFinal_Start_Date': PFinal_Start_Date
               }


    return render(request, 'dashboard.html',context=context)




