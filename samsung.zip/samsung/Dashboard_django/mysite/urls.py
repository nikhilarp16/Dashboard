"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
import manage
import pandas as pd


bdf= pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')
if(len(bdf)==0):
    Project=[]
    cfg=[]
else:
    Project= list(bdf['Project'])
    cfg=list(bdf['Configuration'])
urlpatterns = [
    path('', include('trialdata.urls')),
    path('addProject', include('addProject.urls')),
    path('delete', include('delete.urls')),
    path('dashboard', include('dashboard.urls')),
    path('admin', admin.site.urls),
    path('modifyProject', include("modifyProject.urls")),
    path('downloads', include('downloads.urls')),
    path('Project', include('Project.urls'))

]
for x in range(len(Project)):
       if(cfg[x]=='N/A'): 
            urlpatterns.append(path('Project/' + Project[x], include('Project.urls')))
       else:
           urlpatterns.append(path('Project/' + Project[x]+'/'+cfg[x], include('Project.urls')))
bdf= pd.read_excel(manage.trial_xlsx, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')
if(len(bdf)==0):
    Project=[]
    cfg=[]
else:
    Project= list(bdf['Project'])
    cfg=list(bdf['Configuration'])
for x in range(len(Project)):
       if(cfg[x]=='N/A'):
            urlpatterns.append(path('Project/' + Project[x], include('Project.urls')))
       else:
           urlpatterns.append(path('Project/' + Project[x]+'/'+cfg[x], include('Project.urls')))



