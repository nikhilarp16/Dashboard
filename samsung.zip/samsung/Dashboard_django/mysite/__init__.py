def pupdate():
    print('this runs')