from django.conf.urls import url
from django.urls import path
from django.views.generic import RedirectView
import pandas as pd
import manage
from . import views

bdf= pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,engine='openpyxl')
if(len(bdf)==0):
    Project=[]
else:
    Project= list(bdf['Project'])

urlpatterns = [
    path('', views.index, name='index'),

]


