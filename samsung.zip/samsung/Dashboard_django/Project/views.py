import datetime
from datetime import datetime
from django.shortcuts import render
from django.contrib import messages
import pandas as pd
from openpyxl import load_workbook
import math;
from datetime import date
import manage
from django.urls import resolve

def index(request):
    current_url = resolve(request.path_info).route

    # Read Excel
    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False,
                        engine='openpyxl')
    if(request.method!='POST'):
        print('post')
        name=current_url.split('/')[1]
        x = []
        x.append(name)
        if(len(current_url.split('/'))==3):
            cfg=current_url.split('/')[2]
            x.append(cfg)


    else:
        name = request.POST.get('submit', '')
        x=name.split(':')
    #print(x)
    writer=manage.folder+x[0]+".xlsx"


    if(len(x)>1):
        wq = bdf['Configuration'] == x[1]
        sheetname=x[1]
    else:

        wq = bdf['Configuration'] == 'N/A'
        sheetname="Sheet1"

    q = bdf['Project'] == x[0]


    y = 0
    n = []

    for x in q:
        if x == wq[y]==True:
            n.append(y)
        y = y + 1
    print(n)
    df_p = pd.read_excel(writer, sheet_name=sheetname, engine='openpyxl')
    cs = list(bdf['CurrentStatus'])


    #Get lists from Sheet2
    Project= list(bdf['Project'])
    cfg=list(bdf['Configuration'])
    soc=list(bdf['SOC'])
    owner=list(bdf['Owner'])

    Start_Date=list(bdf['PreAlpha_ExpectedStart'])
    End_Date= list(bdf['Final_ExpectedEnd'])
    Alpha_Start_Date=list(bdf['Alpha_ExpectedStart'])
    Beta_Start_Date=list(bdf['Beta_ExpectedStart'])
    Final_Start_Date=list(bdf['Final_ExpectedStart'])



    #Get lists from Sheet1
    Project_e = list(bdf['Project'])
    cfg_e = list(bdf['Configuration'])

    tb=list(bdf['TB'])
    test=list(bdf['Test'])
    JiraClosed=list(bdf['JiraClosed'])
    JiraResolved=list(bdf['JiraResolved'])
    JiraOpen=list(bdf['JiraOpen'])
    PreAlpha_Completed=[]
    Alpha_Completed = []
    Beta_Completed = []
    Final_Completed = []
    i=0

    PreAlpha_Completed=list(bdf['PreAlpha'])
    Alpha_Completed=list(bdf['Alpha'])
    Beta_Completed=list(bdf['Beta'])
    Final_Completed=list(bdf['Final'])

    #print(Project)
    df_p["Date"] = pd.to_datetime(df_p["Date"]).dt.strftime("%m/%d/%y")
    FCAssertion = list(df_p['FC_Assertion'])
    FCCG = list(df_p['FC_CoverGroup'])
    FCTotal = [float((sum(i)) / max(len(i), 1)) for i in zip(FCAssertion, FCCG)]
    CC_Block = list(df_p['CC_Block'])
    CC_Expression = list(df_p['CC_Expression'])
    CC_Toggle = list(df_p['CC_Toggle'])
    CC_FSM=list(df_p['CC_FSM'])
    if (bdf._get_value(n[0], 'CCFSM') == '0/0'):
        CC_Total = [float((sum(i)) / max(len(i), 1)) for i in zip(CC_Block, CC_Expression, CC_Toggle)]
    else:
        CC_Total=[float((sum(i)) / max(len(i), 1)) for i in zip(CC_Block, CC_Expression,CC_Toggle,CC_FSM)]
    R_Passing=list(df_p['R_Passing'])
    R_InProgress=list(df_p['R_InProgress'])
    R_Failing=list(df_p['R_Failing'])




    context={'name':name,'Project':Project,'cfg':cfg,'soc':soc,'owner':owner ,'cs':cs,'tb':tb,'test':test,'Start_Date':Start_Date,'End_Date':End_Date,'Alpha_Start_Date':Alpha_Start_Date,
             'Beta_Start_Date':Beta_Start_Date,'Final_Start_Date':Final_Start_Date,'PreAlpha_Completed':PreAlpha_Completed,
             'Alpha_Completed':Alpha_Completed,'Beta_Completed':Beta_Completed,'Final_Completed':Final_Completed,'n':n,
             'RunDate':list(df_p['Date']),"FCAssertion": FCAssertion, 'FCCG': FCCG,'FCTotal':FCTotal,'CC_Block':CC_Block,
             'CC_Expression':CC_Expression,'CC_Toggle':CC_Toggle,'CC_FSM':CC_FSM,'CC_Total':CC_Total,'R_Passing':R_Passing,'R_InProgress':R_InProgress,
             'R_Failing':R_Failing,'JiraOpen':JiraOpen,'JiraResolved':JiraResolved,'JiraClosed':JiraClosed
             }


    return render(request, 'trial.html', context=context)




