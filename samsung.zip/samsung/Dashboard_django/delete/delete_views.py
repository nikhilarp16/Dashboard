import openpyxl
from django.shortcuts import render
from django.contrib import messages
import pandas as pd
import os
from django.template import loader
from openpyxl import load_workbook
from pandas import ExcelWriter
import manage

def index(request):

    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        engine='openpyxl')
    # Get lists from Sheet2
    if (len(bdf) == 0):
        Project = []
        Project_v=[]
        cfg=[]
    else:
        Project = list(bdf['Project'])
        Project_v = list(bdf['Project'].unique())

        cfg = list(bdf['Configuration'])

    context = {'Project_v':Project_v,'Project': Project, 'cfg': cfg}


    return render(request, 'delete_project.html',context=context)
def save(request):

    bdf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        engine='openpyxl')
    df2 = pd.read_excel(manage.base_link, sheet_name="Sheet2", keep_default_na=False,
                        engine='openpyxl')
    name = request.POST.get('Name', '')
    ip=request.POST.get('ip','')
    print(name)
    print(ip)
    try:
      q=bdf['Project']==name
      wq=bdf['Configuration']==ip
      if(ip=='All'):
         dataframe=bdf.drop(q.index[q].tolist())
         dataframe2 = df2.drop(q.index[q].tolist())
      else:
        dataframe = bdf.drop(q.index[wq].tolist())
        dataframe2 = df2.drop(q.index[wq].tolist())
    except FileNotFoundError:
        messages.error(request, 'Cannot get Name')
        pass
    writer = pd.ExcelWriter(manage.base_link, date_format='MM-DD-YYYY',
                            datetime_format='MM-DD-YYYY', engine='openpyxl')
    # try to open an existing workbook
    workbook = load_workbook(manage.base_link)
    workbook.remove_sheet(workbook.get_sheet_by_name('Sheet1'))
    workbook.create_sheet('Sheet1')
    workbook.remove_sheet(workbook.get_sheet_by_name('Sheet2'))
    workbook.create_sheet('Sheet2')
    workbook.save(manage.base_link)

    writer = pd.ExcelWriter(manage.base_link, date_format='MM-DD-YYYY',
                            datetime_format='MM-DD-YYYY', engine='openpyxl')
    writer.book = load_workbook(manage.base_link)
    writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
    dataframe.to_excel(writer, index=False, sheet_name='Sheet1')
    dataframe2.to_excel(writer, index=False, sheet_name='Sheet2')
    writer.close()


    excel=manage.folder+name+".xlsx"
    if(os.path.isfile(excel)):
        workbook = openpyxl.load_workbook(excel);
        if ip!='All':
            workbook.remove_sheet(workbook.get_sheet_by_name(ip))
            workbook.save(excel)
        else:

            os.remove(excel)
    ldf = pd.read_excel(manage.base_link, sheet_name="Sheet1", keep_default_na=False,
                        engine='openpyxl')
    # Get lists from Sheet2
    if(len(ldf)==0):
        Project=[]
        cfg=[]
    else:
        Project = list(ldf['Project'])
        cfg = list(ldf['Configuration'])

    context = {'Project': Project, 'cfg': cfg}

    # Name_v= [1,2,3,4]
    messages.success(request, 'Delete successful')
    return render(request,'delete_project.html', context=context)
