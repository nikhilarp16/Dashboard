from django.apps import AppConfig


class ReaderConfig(AppConfig):
    name = 'delete'
