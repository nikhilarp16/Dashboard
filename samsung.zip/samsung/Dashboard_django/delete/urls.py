from django.conf.urls import url
from django.urls import path
from django.views.generic import RedirectView

from . import delete_views

urlpatterns = [

    path('', delete_views.index, name='index'),

    path('save', delete_views.save, name='save'),
   # path('', delete_views.select, name='select'),
#url(r'^favicon\.ico$',RedirectView.as_view(url='/static/images/favicon.ico')),
]