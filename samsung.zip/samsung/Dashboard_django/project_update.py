import os
from datetime import date
import datetime
import openpyxl
import pandas as pd
from openpyxl import load_workbook
from pandas import ExcelWriter
from datetime import datetime
import shutil
import manage
def update_xlsx():


    folder = manage.folder
    weekday=manage.weekday
    base_link = manage.trial_xlsx
    bdf = pd.read_excel(base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
    Project=list(bdf['Project'])
    cfg = list(bdf['Configuration'])
    comp=list(bdf['CurrentStatus'])
    for i in range(len(Project)):

     if(comp[i]!='Completed'):
        #print(Project[i])
       if(cfg[i]=='N/A'):
            sheetname="Sheet1"
       else:
            sheetname=cfg[i]

       proj_df = pd.read_excel(folder+Project[i]+'.xlsx', sheet_name=sheetname, keep_default_na=False,
                                    index=False, engine='openpyxl')

       z=[i]
       if (date.today().weekday() != weekday):
           for x in range(len(proj_df)):
               if(bdf._get_value(z[0], 'CCFSM')=='0/0'):
                   cc_fsm=0
               else:
                   cc_fsm=round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,4)


               d1 = list(pd.to_datetime(proj_df['Date']).dt.strftime("%m-%d-%Y"))
               d3 = datetime.strptime(d1[len(d1) - 1], '%m-%d-%Y')
               if (round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split(
                    "/"))))) * 100,4) == round(proj_df._get_value((len(d1) - 1), 'FC_Assertion'),4) and
                    round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split(
                        "/"))))) * 100 ,4)== round(proj_df._get_value((len(d1) - 1), 'FC_CoverGroup'),4) and
                    round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split(
                        "/"))))) * 100,4) == round(proj_df._get_value((len(d1) - 1), 'CC_Block'),4) and
                       round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split(
                           "/"))))) * 100, 4)==round(proj_df._get_value((len(d1) - 1), 'CC_Expression'),4) and
                       round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split(
                           "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'CC_Toggle'), 4) and
                       cc_fsm == round(proj_df._get_value((len(d1) - 1), 'CC_FSM'), 4) and
                       int(bdf._get_value(z[0], 'RegressionPassing'))==proj_df._get_value((len(d1) - 1), 'R_Passing') and
                       int(bdf._get_value(z[0], 'RegressionInProgress'))== proj_df._get_value((len(d1) - 1), 'R_InProgress')and
                        int(bdf._get_value(z[0], 'RegressionFailing'))== proj_df._get_value((len(d1) - 1), 'R_Failing')
               ):


                    break

               else:

                if (d3.strftime('%Y-%m-%d') == datetime.today().strftime('%Y-%m-%d')):
                    print('today')
                    proj_df = proj_df.drop(len(proj_df) - 1)
                    workbook = load_workbook(folder + Project[i] + '.xlsx')
                    workbook.remove_sheet(workbook.get_sheet_by_name(sheetname))
                    workbook.create_sheet(sheetname)
                    workbook.save(folder + Project[i] + '.xlsx')

                    writer = pd.ExcelWriter(folder + Project[i] + '.xlsx', date_format='MM-DD-YYYY',
                                            datetime_format='MM-DD-YYYY', engine='openpyxl')
                    writer.book = load_workbook(folder + Project[i] + '.xlsx')
                    writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
                    proj_df.to_excel(writer, index=False, sheet_name=sheetname)
                    #print(proj_df)
                    writer.close()
                    print(proj_df)
                if ((bdf._get_value(z[0], 'CCFSM')) == '0/0'):
                        df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                            eval('/'.join(
                                map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                           'FC_CoverGroup': eval('/'.join(
                                               map(str, map(float,
                                                            (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                           'CC_Block': eval('/'.join(
                                               map(str,
                                                   map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                           'CC_Expression': eval('/'.join(
                                               map(str, map(float,
                                                            (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                           'CC_Toggle': eval('/'.join(
                                               map(str,
                                                   map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                           'CC_FSM': 0,
                                           'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                           'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                           'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                           })

                else:
                        df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                            eval('/'.join(
                                map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                           'FC_CoverGroup': eval('/'.join(
                                               map(str, map(float,
                                                            (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                           'CC_Block': eval('/'.join(
                                               map(str,
                                                   map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                           'CC_Expression': eval('/'.join(
                                               map(str, map(float,
                                                            (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                           'CC_Toggle': eval('/'.join(
                                               map(str,
                                                   map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                           'CC_FSM': eval('/'.join(
                                               map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,
                                           'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                           'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                           'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                           })

                s = proj_df.append(df)
                #print(proj_df)
                book = load_workbook(folder + Project[i] + '.xlsx')
                writer = pd.ExcelWriter(folder + Project[i] + '.xlsx',
                                            date_format='MM-DD-YYYY', datetime_format='MM-DD-YYYY', engine='openpyxl')
                writer.book = book
                writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

                s.to_excel(writer, sheet_name=sheetname, index=False, startrow=0)
                writer.save()
                writer.close()

       else:
        copy = folder + "Backup_" + date.today().strftime("%m-%d-%Y") + ".xlsx"
        shutil.copy(base_link, copy)

        for x in range(len(proj_df)):
            d1=list(pd.to_datetime(proj_df['Date']).dt.strftime("%m-%d-%Y"))
            d3 = datetime.strptime(d1[len(d1) - 1], '%m-%d-%Y')
            d2 = datetime.today()
            if (abs((d2 - d3).days) > 7):
                break
            #print(d3)
            if (d3.weekday()!=weekday):
                if (len(proj_df)==1):
                    break
                else:

                    proj_df = proj_df.drop(len(proj_df) - 1)

            else:
                if (proj_df.iloc[len(proj_df) - 1, 0] == date.today().strftime("%m-%d-%Y")):
                    proj_df = proj_df.drop(len(proj_df) - 1)

                break

            workbook = load_workbook(folder + Project[i] + '.xlsx')
            workbook.remove_sheet(workbook.get_sheet_by_name(sheetname))
            workbook.create_sheet(sheetname)
            workbook.save(folder + Project[i] + '.xlsx')

            writer = pd.ExcelWriter(folder + Project[i] + '.xlsx', date_format='MM-DD-YYYY',
                                    datetime_format='MM-DD-YYYY', engine='openpyxl')
            writer.book = load_workbook(folder+ Project[i] + '.xlsx')
            writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
            proj_df.to_excel(writer, index=False, sheet_name=sheetname)

            writer.close()

        if ((bdf._get_value(z[0], 'CCFSM')) == '0/0'):
                df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                    eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                   'FC_CoverGroup': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                   'CC_Block': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                   'CC_Expression': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                   'CC_Toggle': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                   'CC_FSM': 0,
                                   'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                   'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                   'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                   })

        else:
                df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                    eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                   'FC_CoverGroup': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                   'CC_Block': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                   'CC_Expression': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                   'CC_Toggle': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                   'CC_FSM': eval('/'.join(
                                       map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,
                                   'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                   'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                   'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                   })

        s = proj_df.append(df)

        book = load_workbook(folder+Project[i]+'.xlsx')
        writer = pd.ExcelWriter(folder+Project[i]+'.xlsx',
                                date_format='MM-DD-YYYY', datetime_format='MM-DD-YYYY', engine='openpyxl')
        writer.book = book
        writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

        s.to_excel(writer, sheet_name=sheetname, index=False,startrow=0)
        writer.save()
        writer.close()

    folder = manage.folder
    weekday = manage.weekday
    base_link = manage.data
    bdf = pd.read_excel(base_link, sheet_name="Sheet1", keep_default_na=False,
                        index=False, engine='openpyxl')
    Project = list(bdf['Project'])
    cfg = list(bdf['Configuration'])
    comp = list(bdf['CurrentStatus'])
    for i in range(len(Project)):

        if (comp[i] != 'Completed'):
            # print(Project[i])
            if (cfg[i] == 'N/A'):
                sheetname = "Sheet1"
            else:
                sheetname = cfg[i]

            proj_df = pd.read_excel(folder + Project[i] + '.xlsx', sheet_name=sheetname, keep_default_na=False,
                                    index=False, engine='openpyxl')

            z = [i]
            if (date.today().weekday() != weekday):
                for x in range(len(proj_df)):
                    if (bdf._get_value(z[0], 'CCFSM') == '0/0'):
                        cc_fsm = 0
                    else:
                        cc_fsm = round(
                            eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100, 4)

                    d1 = list(pd.to_datetime(proj_df['Date']).dt.strftime("%m-%d-%Y"))
                    d3 = datetime.strptime(d1[len(d1) - 1], '%m-%d-%Y')
                    if (round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split(
                            "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'FC_Assertion'), 4) and
                            round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split(
                                "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'FC_CoverGroup'), 4) and
                            round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split(
                                "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'CC_Block'), 4) and
                            round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCExpression')).split(
                                "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'CC_Expression'), 4) and
                            round(eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split(
                                "/"))))) * 100, 4) == round(proj_df._get_value((len(d1) - 1), 'CC_Toggle'), 4) and
                            cc_fsm == round(proj_df._get_value((len(d1) - 1), 'CC_FSM'), 4) and
                            int(bdf._get_value(z[0], 'RegressionPassing')) == proj_df._get_value((len(d1) - 1),
                                                                                                 'R_Passing') and
                            int(bdf._get_value(z[0], 'RegressionInProgress')) == proj_df._get_value((len(d1) - 1),
                                                                                                    'R_InProgress') and
                            int(bdf._get_value(z[0], 'RegressionFailing')) == proj_df._get_value((len(d1) - 1),
                                                                                                 'R_Failing')
                    ):


                        break

                    else:

                        if (d3.strftime('%Y-%m-%d') == datetime.today().strftime('%Y-%m-%d')):
                            print('today')
                            proj_df = proj_df.drop(len(proj_df) - 1)
                            workbook = load_workbook(folder + Project[i] + '.xlsx')
                            workbook.remove_sheet(workbook.get_sheet_by_name(sheetname))
                            workbook.create_sheet(sheetname)
                            workbook.save(folder + Project[i] + '.xlsx')

                            writer = pd.ExcelWriter(folder + Project[i] + '.xlsx', date_format='MM-DD-YYYY',
                                                    datetime_format='MM-DD-YYYY', engine='openpyxl')
                            writer.book = load_workbook(folder + Project[i] + '.xlsx')
                            writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
                            proj_df.to_excel(writer, index=False, sheet_name=sheetname)
                            # print(proj_df)
                            writer.close()
                            print(proj_df)
                        if ((bdf._get_value(z[0], 'CCFSM')) == '0/0'):
                            df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                                eval('/'.join(
                                    map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                               'FC_CoverGroup': eval('/'.join(
                                                   map(str, map(float,
                                                                (bdf._get_value(z[0], 'FCCoverGroup')).split(
                                                                    "/"))))) * 100,
                                               'CC_Block': eval('/'.join(
                                                   map(str,
                                                       map(float,
                                                           (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                               'CC_Expression': eval('/'.join(
                                                   map(str, map(float,
                                                                (bdf._get_value(z[0], 'CCExpression')).split(
                                                                    "/"))))) * 100,
                                               'CC_Toggle': eval('/'.join(
                                                   map(str,
                                                       map(float,
                                                           (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                               'CC_FSM': 0,
                                               'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                               'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                               'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                               })

                        else:
                            df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                                eval('/'.join(
                                    map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                               'FC_CoverGroup': eval('/'.join(
                                                   map(str, map(float,
                                                                (bdf._get_value(z[0], 'FCCoverGroup')).split(
                                                                    "/"))))) * 100,
                                               'CC_Block': eval('/'.join(
                                                   map(str,
                                                       map(float,
                                                           (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                               'CC_Expression': eval('/'.join(
                                                   map(str, map(float,
                                                                (bdf._get_value(z[0], 'CCExpression')).split(
                                                                    "/"))))) * 100,
                                               'CC_Toggle': eval('/'.join(
                                                   map(str,
                                                       map(float,
                                                           (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                               'CC_FSM': eval('/'.join(
                                                   map(str,
                                                       map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,
                                               'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                               'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                               'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                               })

                        s = proj_df.append(df)
                        # print(proj_df)
                        book = load_workbook(folder + Project[i] + '.xlsx')
                        writer = pd.ExcelWriter(folder + Project[i] + '.xlsx',
                                                date_format='MM-DD-YYYY', datetime_format='MM-DD-YYYY',
                                                engine='openpyxl')
                        writer.book = book
                        writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

                        s.to_excel(writer, sheet_name=sheetname, index=False, startrow=0)
                        writer.save()
                        writer.close()

            else:
                copy = folder + "Backup_" + date.today().strftime("%m-%d-%Y") + ".xlsx"
                shutil.copy(base_link, copy)

                for x in range(len(proj_df)):
                    d1 = list(pd.to_datetime(proj_df['Date']).dt.strftime("%m-%d-%Y"))
                    d3 = datetime.strptime(d1[len(d1) - 1], '%m-%d-%Y')
                    d2 = datetime.today()
                    if (abs((d2 - d3).days) > 7):
                        break
                    # print(d3)
                    if (d3.weekday() != weekday):
                        if (len(proj_df) == 1):
                            break
                        else:

                            proj_df = proj_df.drop(len(proj_df) - 1)

                    else:
                        if (proj_df.iloc[len(proj_df) - 1, 0] == date.today().strftime("%m-%d-%Y")):
                            proj_df = proj_df.drop(len(proj_df) - 1)

                        break

                    workbook = load_workbook(folder + Project[i] + '.xlsx')
                    workbook.remove_sheet(workbook.get_sheet_by_name(sheetname))
                    workbook.create_sheet(sheetname)
                    workbook.save(folder + Project[i] + '.xlsx')

                    writer = pd.ExcelWriter(folder + Project[i] + '.xlsx', date_format='MM-DD-YYYY',
                                            datetime_format='MM-DD-YYYY', engine='openpyxl')
                    writer.book = load_workbook(folder + Project[i] + '.xlsx')
                    writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
                    proj_df.to_excel(writer, index=False, sheet_name=sheetname)

                    writer.close()

                if ((bdf._get_value(z[0], 'CCFSM')) == '0/0'):
                    df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                        eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                       'FC_CoverGroup': eval('/'.join(
                                           map(str,
                                               map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                       'CC_Block': eval('/'.join(
                                           map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                       'CC_Expression': eval('/'.join(
                                           map(str,
                                               map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                       'CC_Toggle': eval('/'.join(
                                           map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                       'CC_FSM': 0,
                                       'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                       'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                       'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                       })

                else:
                    df = pd.DataFrame({'Date': date.today().strftime("%m-%d-%Y"), 'FC_Assertion': [
                        eval('/'.join(map(str, map(float, (bdf._get_value(z[0], 'FCAssertion')).split("/"))))) * 100],
                                       'FC_CoverGroup': eval('/'.join(
                                           map(str,
                                               map(float, (bdf._get_value(z[0], 'FCCoverGroup')).split("/"))))) * 100,
                                       'CC_Block': eval('/'.join(
                                           map(str, map(float, (bdf._get_value(z[0], 'CCBlock')).split("/"))))) * 100,
                                       'CC_Expression': eval('/'.join(
                                           map(str,
                                               map(float, (bdf._get_value(z[0], 'CCExpression')).split("/"))))) * 100,
                                       'CC_Toggle': eval('/'.join(
                                           map(str, map(float, (bdf._get_value(z[0], 'CCToggle')).split("/"))))) * 100,
                                       'CC_FSM': eval('/'.join(
                                           map(str, map(float, (bdf._get_value(z[0], 'CCFSM')).split("/"))))) * 100,
                                       'R_Passing': int(bdf._get_value(z[0], 'RegressionPassing')),
                                       'R_InProgress': int(bdf._get_value(z[0], 'RegressionInProgress')),
                                       'R_Failing': int(bdf._get_value(z[0], 'RegressionFailing'))
                                       })

                s = proj_df.append(df)

                book = load_workbook(folder + Project[i] + '.xlsx')
                writer = pd.ExcelWriter(folder + Project[i] + '.xlsx',
                                        date_format='MM-DD-YYYY', datetime_format='MM-DD-YYYY', engine='openpyxl')
                writer.book = book
                writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

                s.to_excel(writer, sheet_name=sheetname, index=False, startrow=0)
                writer.save()
                writer.close()